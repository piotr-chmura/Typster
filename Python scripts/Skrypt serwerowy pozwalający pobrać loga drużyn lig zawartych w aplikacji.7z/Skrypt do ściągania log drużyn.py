import requests

leagues = ["2", "3", "39", "61", "78", "106", "135", "140", "848"]

url = "https://api-football-v1.p.rapidapi.com/v3/teams"

querystring = {"league": "2", "season": "2022"}

headers = {
    "X-RapidAPI-Key": "KLUCZ API",
    "X-RapidAPI-Host": "api-football-v1.p.rapidapi.com"
}
path = "ŚCIEŻKA ZAPISU MUSZĄ ISTNIEĆ FOLDERY Z NUMERAMI ID LIG"


for league in leagues:
    querystring["league"] = league
    print(league, '\t')
    response = requests.request("GET", url, headers=headers, params=querystring)
    res = response.json()
    for team in res['response']:
        img_data = requests.get(team['team']['logo']).content
        with open(path + league + '/' + team['team']['name'].replace("/", "-") + '.png', 'wb') as handler:
            handler.write(img_data)